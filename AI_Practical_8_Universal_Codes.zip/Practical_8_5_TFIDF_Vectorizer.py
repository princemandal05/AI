# AI Practical 8.5 - TF-IDF Vectorizer
# Install command:
# pip install scikit-learn

from sklearn.feature_extraction.text import TfidfVectorizer

# CHANGE THE SENTENCES HERE
documents = [
    "I love machine learning",
    "Machine learning is interesting",
    "I love artificial intelligence"
]

vectorizer = TfidfVectorizer()
X = vectorizer.fit_transform(documents)

print("Vocabulary:")
print(vectorizer.get_feature_names_out())

print("\nTF-IDF Vectors:")
print(X.toarray())
