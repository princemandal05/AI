# AI Practical 8.1 - NLTK Text Processing
# Install command:
# pip install nltk

import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.stem import PorterStemmer, WordNetLemmatizer

# Download required NLTK resources
for resource in ["punkt", "punkt_tab", "stopwords", "wordnet",
                 "omw-1.4", "averaged_perceptron_tagger_eng"]:
    nltk.download(resource, quiet=True)

# CHANGE THIS SENTENCE
text = "Natural language processing is interesting"

tokens = word_tokenize(text)
stemmer = PorterStemmer()
lemmatizer = WordNetLemmatizer()

stop_words = set(stopwords.words("english"))
filtered_tokens = [
    word for word in tokens
    if word.isalpha() and word.lower() not in stop_words
]

stemmed_tokens = [stemmer.stem(word) for word in filtered_tokens]
lemmatized_tokens = [
    lemmatizer.lemmatize(word.lower()) for word in filtered_tokens
]
pos_tags = nltk.pos_tag(filtered_tokens)

print("Tokens:", tokens)
print("Filtered Tokens:", filtered_tokens)
print("Stemmed Tokens:", stemmed_tokens)
print("Lemmatized Tokens:", lemmatized_tokens)
print("POS Tags:", pos_tags)
