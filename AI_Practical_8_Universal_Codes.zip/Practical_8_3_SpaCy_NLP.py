# AI Practical 8.3 - spaCy NLP Processing
# Install commands:
# pip install spacy
# python -m spacy download en_core_web_sm

import spacy

nlp = spacy.load("en_core_web_sm")

# CHANGE THIS SENTENCE
text = "Apple is opening a new office in Mumbai."

doc = nlp(text)

print("Tokens and POS:")
for token in doc:
    print(token.text, token.pos_)

print("\nNamed Entities:")
for entity in doc.ents:
    print(entity.text, entity.label_)
