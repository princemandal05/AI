# AI Practical 8.2 - NLTK Bag of Words
# Install command:
# pip install nltk

from nltk.tokenize import word_tokenize
import nltk

nltk.download("punkt", quiet=True)
nltk.download("punkt_tab", quiet=True)

# CHANGE THE SENTENCES HERE
documents = [
    "I love machine learning",
    "Machine learning is interesting",
    "I love artificial intelligence"
]

tokenized_words = [word_tokenize(doc.lower()) for doc in documents]
print("Tokenized Words:", tokenized_words)

vocabulary = sorted(set(
    word for doc in tokenized_words for word in doc
))
print("Vocabulary:", vocabulary)

bow_vectors = []
for doc in tokenized_words:
    vector = []
    for word in vocabulary:
        vector.append(doc.count(word))
    bow_vectors.append(vector)

print("Bag of Words Vectors:")
for vector in bow_vectors:
    print(vector)
