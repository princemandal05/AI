# AI Practical 8.4 - TextBlob Sentiment Analysis
# Install command:
# pip install textblob

from textblob import TextBlob

# CHANGE THIS SENTENCE
text = "The movie was excellent and very entertaining"

blob = TextBlob(text)
sentiment = blob.sentiment

print("Sentiment:", sentiment)
print("Polarity:", sentiment.polarity)
print("Subjectivity:", sentiment.subjectivity)

if sentiment.polarity > 0:
    print("Positive Sentiment")
elif sentiment.polarity < 0:
    print("Negative Sentiment")
else:
    print("Neutral Sentiment")
