# Practical 9 - Backpropagation for AND Gate
# Install once: pip install numpy
import numpy as np

# BOILERPLATE: Input combinations
X = np.array([[0, 0], [0, 1], [1, 0], [1, 1]])

# CHANGE THIS Y ARRAY to train another gate:
# AND: [[0], [0], [0], [1]]
# OR:  [[0], [1], [1], [1]]
Y = np.array([[0], [0], [0], [1]])

np.random.seed(1)
W1 = np.random.randn(2, 4)
b1 = np.zeros((1, 4))
W2 = np.random.randn(4, 1)
b2 = np.zeros((1, 1))
learning_rate = 0.5

def sigmoid(x):
    return 1 / (1 + np.exp(-x))

for epoch in range(10000):
    hidden = sigmoid(np.dot(X, W1) + b1)
    output = sigmoid(np.dot(hidden, W2) + b2)
    error = Y - output
    d_output = error * output * (1 - output)
    d_hidden = np.dot(d_output, W2.T) * hidden * (1 - hidden)
    W2 += learning_rate * np.dot(hidden.T, d_output)
    b2 += learning_rate * np.sum(d_output, axis=0, keepdims=True)
    W1 += learning_rate * np.dot(X.T, d_hidden)
    b1 += learning_rate * np.sum(d_hidden, axis=0, keepdims=True)

hidden = sigmoid(np.dot(X, W1) + b1)
output = sigmoid(np.dot(hidden, W2) + b2)
print("Backpropagation - AND Gate")
print("Predicted output:")
print(np.round(output))
