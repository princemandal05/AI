# Practical 9 - Hebbian Learning for AND Gate
# Install once: pip install numpy
import numpy as np

# BOILERPLATE: Bipolar input combinations
X = np.array([[-1, -1], [-1, 1], [1, -1], [1, 1]])

# CHANGE Y for another gate (bipolar values):
# AND:  [-1, -1, -1,  1]
# OR:   [-1,  1,  1,  1]
# NAND: [ 1,  1,  1, -1]
# NOR:  [ 1, -1, -1, -1]
Y = np.array([-1, -1, -1, 1])

weights = np.zeros(2)
bias = 0
for i in range(len(X)):
    weights += X[i] * Y[i]
    bias += Y[i]

print("Hebbian Learning - AND Gate")
print("Weights:", weights)
print("Bias:", bias)
for row in X:
    net = np.dot(row, weights) + bias
    prediction = 1 if net >= 0 else -1
    print(row, "=", prediction)
