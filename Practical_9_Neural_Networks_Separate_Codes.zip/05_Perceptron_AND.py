# Practical 9 - Perceptron for AND Gate
# Install once: pip install numpy
import numpy as np

# BOILERPLATE: Input combinations
X = np.array([[0, 0], [0, 1], [1, 0], [1, 1]])

# CHANGE Y for another gate:
# AND:  [0, 0, 0, 1]
# OR:   [0, 1, 1, 1]
# NAND: [1, 1, 1, 0]
# NOR:  [1, 0, 0, 0]
Y = np.array([0, 0, 0, 1])

weights = np.zeros(2)
bias = 0
learning_rate = 0.1

for epoch in range(20):
    for i in range(len(X)):
        net = np.dot(X[i], weights) + bias
        prediction = 1 if net > 0 else 0
        error = Y[i] - prediction
        weights += learning_rate * error * X[i]
        bias += learning_rate * error

print("Perceptron - AND Gate")
print("Weights:", weights)
print("Bias:", bias)
for row in X:
    net = np.dot(row, weights) + bias
    prediction = 1 if net > 0 else 0
    print(row, "=", prediction)
