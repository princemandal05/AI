PRACTICAL 9 - NEURAL NETWORKS

Separate Python files:
1. Backpropagation AND
2. Backpropagation OR
3. Hebbian AND
4. Hebbian OR
5. Perceptron AND
6. Perceptron OR

SETUP:
1. Install Python.
2. Open terminal in this folder.
3. Run: pip install numpy
4. Run a file, for example: python 05_Perceptron_AND.py

WHAT TO CHANGE:
- X contains the input combinations and is normally boilerplate.
- Y contains the expected outputs and is the main line to change for a different logic gate.
- Perceptron and Backpropagation use binary outputs (0 and 1).
- Hebbian uses bipolar outputs (-1 and 1).

Perceptron/Backpropagation:
AND  [0, 0, 0, 1]
OR   [0, 1, 1, 1]
NAND [1, 1, 1, 0]
NOR  [1, 0, 0, 0]

Hebbian:
AND  [-1, -1, -1, 1]
OR   [-1, 1, 1, 1]
NAND [1, 1, 1, -1]
NOR  [1, -1, -1, -1]

Note: These are separate study versions for the listed algorithms and gates.
